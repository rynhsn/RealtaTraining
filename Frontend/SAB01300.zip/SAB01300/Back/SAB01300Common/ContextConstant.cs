﻿namespace SAB01300Common
{
    public class ContextConstant
    {
        public const string CATEGORY_ID = "CATEGORY_ID";
    }
}
