﻿namespace SAB01300Common.DTOs
{
    public class SAB01300DTO
    {
        public int CategoryID { get; set; }
        public string CategoryName { get; set; }
        public string Description { get; set; }
    }
}
